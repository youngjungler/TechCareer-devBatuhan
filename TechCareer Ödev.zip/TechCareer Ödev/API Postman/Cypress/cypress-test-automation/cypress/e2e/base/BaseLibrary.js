class BaseLibrary {

    wait(second) {
        cy.wait(second)
    }

}

export default BaseLibrary;