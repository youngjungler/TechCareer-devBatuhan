## Install

# IDEA Install
1. **https://www.jetbrains.com/idea**

# JDK & Java Install
2. **https://www.oracle.com/java/technologies/downloads/**

# Maven Repository
3. **https://mvnrepository.com/**

# Install Maven Dependencies
1. maven-dependency: **org.seleniumhq.selenium**
2. maven-dependency: **junit**
3. maven-dependency: **io.qameta.allure**
4. maven-dependency: **org.aspectj**
5. maven-dependency: **org.testng**
---

- [LinkedIn](https://www.linkedin.com/in/canseker)
- [GitHub](https://github.com/can-seker)
- [Instagram](https://www.instagram.com/can.sekerr)
- [Mail](can.seker.official@gmail.com)